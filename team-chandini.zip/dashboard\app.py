from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st


st.set_page_config(page_title="Dublin Housing Affordability Dashboard", layout="wide")
st.title("Dublin Housing Affordability Analysis (2015-2025)")
st.caption("Research Question: Is housing in Dublin becoming unaffordable relative to income over time?")

base_dir = Path(__file__).resolve().parents[1]
processed_dir = base_dir / "data" / "processed"

yearly_path = processed_dir / "dublin_affordability_yearly.csv"
area_path = processed_dir / "dublin_affordability_by_area.csv"
insights_path = processed_dir / "key_insights.csv"

if not yearly_path.exists():
    st.error("Processed datasets not found. Run: python src/main.py")
    st.stop()

yearly_df = pd.read_csv(yearly_path).sort_values("year")
area_df = pd.read_csv(area_path) if area_path.exists() else pd.DataFrame()
insights_df = pd.read_csv(insights_path) if insights_path.exists() else pd.DataFrame()

col1, col2, col3 = st.columns(3)
with col1:
    st.metric("Latest Avg Price (EUR)", f"{yearly_df.iloc[-1]['avg_price_eur']:,.0f}")
with col2:
    income_valid = yearly_df.dropna(subset=["income_eur"]).sort_values("year")
    if income_valid.empty:
        st.metric("Latest Income (EUR)", "N/A")
    else:
        inc_row = income_valid.iloc[-1]
        st.metric("Latest Income (EUR)", f"{inc_row['income_eur']:,.0f}")
        st.caption(f"Income latest available year: {int(inc_row['year'])}")
with col3:
    aff_valid = yearly_df.dropna(subset=["affordability_index"]).sort_values("year")
    if aff_valid.empty:
        st.metric("Latest Affordability Index", "N/A")
    else:
        aff_row = aff_valid.iloc[-1]
        st.metric("Latest Affordability Index", f"{aff_row['affordability_index']:.2f}")
        st.caption(f"Affordability latest available year: {int(aff_row['year'])}")

fig_price_income = px.line(
    yearly_df,
    x="year",
    y=["avg_price_eur", "income_eur"],
    markers=True,
    title="Dublin Property Price vs Income Trend",
    labels={"value": "EUR", "year": "Year", "variable": "Metric"},
)
st.plotly_chart(fig_price_income, width="stretch")

if aff_valid.empty:
    st.warning("No affordability points available (income overlap missing).")
else:
    fig_aff = px.line(
        aff_valid,
        x="year",
        y="affordability_index",
        markers=True,
        title="Affordability Index Over Time (Price / Income)",
        color_discrete_sequence=["#D62728"],
    )
    fig_aff.update_xaxes(range=[aff_valid["year"].min() - 0.25, aff_valid["year"].max() + 0.25])
    st.plotly_chart(fig_aff, width="stretch")

if not area_df.empty:
    min_year = int(area_df["year"].min())
    max_year = int(area_df["year"].max())
    if min_year == max_year:
        selected_year = min_year
        st.info(f"Only one year ({selected_year}) is available in current processed area data.")
    else:
        selected_year = st.slider(
            "Select year for area comparison",
            min_value=min_year,
            max_value=max_year,
            value=max_year,
        )
    area_year = area_df[area_df["year"] == selected_year].sort_values("avg_price_eur", ascending=False).head(20)
    fig_area = px.bar(
        area_year,
        x="area",
        y="avg_price_eur",
        title=f"Top 20 Dublin Areas by Average Price ({selected_year})",
        labels={"avg_price_eur": "Average Price (EUR)", "area": "Area"},
        hover_data={"transaction_count": True, "avg_price_eur": ":,.0f"},
    )
    st.plotly_chart(fig_area, width="stretch")

    st.subheader("Area-Year Heatmap")
    top_areas = (
        area_df[area_df["year"] == selected_year]
        .sort_values("avg_price_eur", ascending=False)["area"]
        .head(25)
        .tolist()
    )
    heatmap_df = area_df[area_df["area"].isin(top_areas)].pivot_table(
        index="area", columns="year", values="avg_price_eur", aggfunc="mean"
    )
    fig_heat = px.imshow(
        heatmap_df,
        aspect="auto",
        color_continuous_scale="Viridis",
        labels={"x": "Year", "y": "Area", "color": "Avg Price (EUR)"},
        title="Top-Area Price Heatmap Across Time",
    )
    st.plotly_chart(fig_heat, width="stretch")

if not insights_df.empty:
    st.subheader("Key Insights")
    for _, row in insights_df.iterrows():
        st.write(f"- {row['insight']}: {row['value']}")
