"""
Merge multiple Property Price Register CSV exports into a single file
expected by the ETL pipeline: data/raw/property_prices.csv

Typical workflow:
1. On propertypriceregister.ie, download Dublin + one year at a time (2015..2025).
2. Move those CSVs into data/raw/yearly_ppr/
3. Run: python scripts/merge_yearly_ppr.py
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd


REQUIRED_SUBSTRINGS = ("date of sale", "county", "price")
ENCODING_CANDIDATES = ("utf-8", "utf-8-sig", "cp1252", "latin1")


def _normalize_col(name: str) -> str:
    return str(name).strip().lower()


def validate_columns(columns: list[str]) -> None:
    norm = [_normalize_col(c) for c in columns]
    joined = " ".join(norm)
    missing = [req for req in REQUIRED_SUBSTRINGS if req not in joined]
    if missing:
        raise ValueError(
            "Merged CSV does not look like Property Price Register. "
            f"Missing expected fields (normalized check): {missing}. "
            f"Columns seen: {columns[:20]}{'...' if len(columns) > 20 else ''}"
        )


def read_csv_with_fallback(path: Path) -> pd.DataFrame:
    """Read CSV with encoding fallback for Windows-exported files."""
    last_error: Exception | None = None
    for enc in ENCODING_CANDIDATES:
        try:
            return pd.read_csv(path, low_memory=False, encoding=enc)
        except UnicodeDecodeError as exc:
            last_error = exc
    raise UnicodeDecodeError(
        "utf-8",
        b"",
        0,
        1,
        f"Could not decode {path.name} with tried encodings {ENCODING_CANDIDATES}. Last error: {last_error}",
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="Merge yearly PPR CSV files into one dataset.")
    parser.add_argument(
        "--input-dir",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "data" / "raw" / "yearly_ppr",
        help="Folder containing downloaded PPR CSV files",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(__file__).resolve().parents[1] / "data" / "raw" / "property_prices.csv",
        help="Output merged CSV path",
    )
    args = parser.parse_args()

    if not args.input_dir.is_dir():
        print(f"Input directory not found: {args.input_dir}", file=sys.stderr)
        return 1

    files = sorted(args.input_dir.glob("*.csv"))
    if not files:
        print(f"No CSV files found in {args.input_dir}", file=sys.stderr)
        return 1

    frames = [read_csv_with_fallback(f) for f in files]
    merged = pd.concat(frames, ignore_index=True).drop_duplicates()
    validate_columns(list(merged.columns))

    args.output.parent.mkdir(parents=True, exist_ok=True)
    merged.to_csv(args.output, index=False)
    print(f"Wrote {len(merged):,} rows from {len(files)} file(s) to {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
