# Dublin Housing Affordability Analysis (2015-2025)
**Team X**  
**Team Members (Official Records):**
- Chandini Konduru (25143913)
- Singireddy Sneha (24285854)
- Kapa Adheeshwar Reddy (25122932)

## Abstract
Housing affordability is one of the most pressing urban policy concerns in Dublin because property prices have risen rapidly while household purchasing power has not always kept pace. This project investigates whether housing in Dublin became less affordable relative to income over the period 2015-2025, and whether affordability pressure is distributed evenly across local areas. To answer this question, we designed and implemented an end-to-end analytics system using multiple public datasets and two database technologies, as required by the module brief.

The project integrates three non-Kaggle data sources: (i) the Irish Property Price Register (transaction-level CSV), (ii) the Central Statistics Office (CSO) income dataset via JSON-stat API, and (iii) the CSO population dataset via JSON-stat API as contextual enrichment. The workflow was implemented in Python and organized as a reproducible ETL architecture. Raw records and payloads were persisted in MongoDB to preserve data lineage. Curated outputs were loaded into PostgreSQL for structured querying and dashboard-ready serving. Data processing included schema normalization, temporal filtering, quality checks, aggregation, and the derivation of affordability metrics.

Our principal indicator is an affordability index defined as average annual Dublin property transaction price divided by annual income. Results indicate a clear long-run affordability deterioration over available overlap years, with property prices increasing materially faster than income. Spatial analysis also reveals sustained area-level inequality: several high-cost areas remain persistently expensive across multiple years rather than exhibiting isolated volatility. Outputs were communicated through static analysis plots and a Streamlit dashboard combining KPI cards, trend charts, ranked area bars, heatmaps, and textual insights.

Beyond domain findings, this project demonstrates practical data engineering competencies expected at MSc level: semi-structured API handling, multi-database ETL orchestration, robust error management, reproducibility controls, and audience-sensitive visual design. The report critically discusses methodological decisions, limitations, and future extensions, including inflation-adjusted affordability models, geospatial refinement, and predictive forecasting.

## I. Introduction
Housing affordability has become a structural challenge in many cities where demand growth, constrained supply, and macroeconomic uncertainty interact over long periods. Dublin is a high-relevance case because the market combines strong economic activity with significant pressure on available housing stock. In such environments, a simple upward trend in prices is informative but incomplete. Affordability is a relational concept: it depends on the ratio between housing costs and household income, and is further shaped by local variation in neighborhood-level price dynamics.

This project addresses the following research question:

**RQ: Is housing in Dublin becoming unaffordable relative to income over time (2015-2025), and how does this affordability pressure vary across areas?**

The question is practically relevant to policymakers, investors, and residents, and academically relevant because it requires integration of heterogeneous data structures. From a technical perspective, affordability analytics is not only a statistical exercise; it is a systems problem that includes ingestion, storage, cleaning, transformation, aggregation, validation, and communication.

### A. Project Objectives
The project was designed around five objectives aligned with the module learning outcomes:

1. Build a reproducible analytics pipeline integrating structured and semi-structured datasets.
2. Programmatically store raw and processed data in two different databases (MongoDB and PostgreSQL).
3. Engineer annual affordability metrics and area-level comparisons for Dublin (2015-2025).
4. Produce both static and interactive visual outputs for technical and non-technical audiences.
5. Document methods, challenges, and evaluation in an IEEE-style academic report.

### B. Scope and Contributions
The scope covers Dublin county transactions and annual macro indicators over the target period. The work contributes in two ways. First, it provides empirical evidence on affordability dynamics over time and space. Second, it provides an engineering blueprint for integrating public CSV and JSON-stat data into a traceable ETL pipeline with dual database persistence.

## II. Related Work
Housing affordability has been examined in policy studies, urban economics, and comparative institutional reports. However, literature often emphasizes either conceptual explanation or descriptive indicators, while providing limited implementation detail for reproducible city-level analytics systems.

Corrigan et al. [1] discuss Irish market dynamics in terms of supply frictions and persistent demand pressure. Their framing helps explain why prices may remain elevated despite policy interventions. A limitation for technical implementation is that affordability is treated largely as a policy outcome rather than as a reproducible computational index integrated from heterogeneous sources.

Norris and Byrne [2] evaluate affordability within Irish policy transitions and social outcomes. Their work effectively contextualizes affordability as a social issue, but does not provide a full ETL architecture combining transaction data and semi-structured API indicators. For this module, the engineering dimension is central and requires explicit data pipeline design.

OECD comparative work [3] shows that affordability deterioration can occur even during periods of income growth when housing supply elasticity is weak. This supports the methodological choice to analyze price-income ratios rather than single-metric trends. At the same time, cross-country normalization can mask local patterns relevant for Dublin-specific decision support.

Glaeser and Gyourko [4] provide a theoretical basis for persistent divergence between housing prices and wages in constrained urban environments. Their macro framing supports the interpretation of long-run affordability pressure but does not prescribe data integration methods for public Irish datasets.

Institutional Irish sources from CSO and ESRI [5], [6] provide high-quality indicators and policy framing, yet data delivery is fragmented across formats and interfaces (CSV downloads, JSON-stat APIs, multiple schema conventions). This fragmentation directly motivates our engineering approach: preserve raw lineage in a document database, then build curated relational outputs for analysis and dashboard serving.

### A. Critical Synthesis
The literature strongly supports the social and economic importance of affordability analysis, but reveals three practical gaps:

1. Limited examples of reproducible implementation that combine high-volume transaction records with semi-structured APIs.
2. Limited methodological transparency regarding data quality rules and schema harmonization.
3. Limited integration of engineering architecture and visual communication in a single, end-to-end workflow.

Our project addresses these gaps by coupling domain analysis with explicit ETL design and audited data flow.

## III. Data Processing Methodology
This section details data sources, architecture, algorithms, technology choices, and challenges encountered.

### A. Data Sources and Justification
Three public datasets were selected because they are non-Kaggle, high-volume, and complementary:

1. **Property Price Register (PPR)** [7]  
   - Format: CSV (structured)  
   - Volume: 198,057 Dublin-related records in the merged local input  
   - Role: primary housing cost signal (transaction-level prices)

2. **CSO Income Dataset (SIA14, JSON-stat API)** [5]  
   - Format: JSON (semi-structured)  
   - Parsed volume: 1,056 records  
   - Role: annual income denominator for affordability index

3. **CSO Population Dataset (F1015, JSON-stat API)** [5]  
   - Format: JSON (semi-structured)  
   - Parsed volume: 13,020 records  
   - Role: optional contextual normalization (`price_per_1000_residents`)

The combination satisfies the requirement that each source has substantial record count and that at least one dataset is semi-structured.

### B. System Architecture and Pipeline Design
The ETL system is modular and implemented in Python:

- `src/extract.py`: CSV loading, API retrieval, JSON-stat parsing, raw persistence.
- `src/transform.py`: cleaning, harmonization, metric engineering, aggregation.
- `src/load.py`: PostgreSQL DDL and structured loads.
- `src/main.py`: orchestration of full extract-transform-load sequence.
- `src/analyze.py`: static figure generation and summary insight export.
- `dashboard/app.py`: interactive dashboard for exploration and communication.

### C. Data Flow Diagram
The following flow summarizes the implemented data lifecycle:

```mermaid
flowchart LR
    A[PPR CSV] --> E[Extract Layer]
    B[CSO Income API JSON-stat] --> E
    C[CSO Population API JSON-stat] --> E
    E --> M[(MongoDB Raw Zone)]
    E --> T[Transform Layer]
    T --> P[(PostgreSQL Curated Zone)]
    T --> F[Processed CSV Outputs]
    P --> D[Streamlit Dashboard]
    F --> G[Static Analysis Figures]
```

### D. Raw Data Management (MongoDB)
Raw ingestion stores both original API payloads and parsed rows to preserve lineage and reprocessing capability:

- `property_prices_raw`
- `cso_income_raw`
- `cso_income_parsed_raw`
- `cso_population_raw`
- `cso_population_parsed_raw`

This design allows reproducibility checks when source API schemas evolve. It also supports transparent debugging by retaining immutable snapshots of upstream responses.

### E. Cleaning and Standardization Algorithms
#### 1) Property data cleaning
Property records are standardized by:

- renaming heterogeneous column labels,
- parsing `sale_date` to datetime,
- extracting `year`,
- converting price strings to numeric values,
- filtering county rows to Dublin,
- restricting years to analysis window (2015-2025),
- excluding implausible low-value transactions (`price_eur > 10,000`).

This process removes format noise and aligns records for annual aggregation.

#### 2) JSON-stat parsing and income harmonization
CSO payloads use multidimensional JSON-stat structures with variable dimension names. The parser:

- detects dimension order from payload metadata,
- reconstructs row combinations,
- maps values to a tabular frame,
- normalizes time and value fields into numeric `year` and `income_eur`,
- applies region filtering with robust fallbacks when expected labels are unavailable.

This dynamic parsing strategy was essential because API fields are not always identical across cubes or years.

#### 3) Population cleaning
Population data are harmonized similarly into annual `year` and `population` series, then optionally merged into the yearly affordability table.

### F. Feature Engineering and Integration
Core yearly metrics are generated from cleaned property records:

- `avg_price_eur`
- `median_price_eur`
- `sales_count`

These are merged with income and (optionally) population by year. Derived indicators:

- `affordability_index = avg_price_eur / income_eur`
- `price_growth_pct`
- `income_growth_pct`
- `affordability_delta_pct`
- `price_per_1000_residents` (when population available)

Area-level aggregation is computed at `(year, area)` level. To avoid excessive `Unknown` categories caused by missing Eircodes, area extraction uses a hybrid strategy:

1. Eircode prefix when available,
2. address parsing fallback (including Dublin district patterns),
3. sanitized locality segment fallback.

A minimum transaction threshold (`transaction_count >= 10`) reduces unstable low-volume area estimates.

### G. Processed Storage (PostgreSQL)
Curated outputs are loaded into:

- `dublin_affordability_yearly`
- `dublin_affordability_area`
- `project_insights`

Relational storage supports downstream querying, deterministic reloads, and dashboard serving. During implementation, area strings exceeded the original `VARCHAR(20)` length; schema width was expanded to avoid truncation errors, illustrating practical database maintenance under evolving transformation logic.

### H. Programming and Data Engineering Challenges
The project encountered several non-trivial implementation challenges:

1. **PowerShell packaging parse issue:** `param(...)` was not at script top; fixed by reordering statements.
2. **Area collapse to unknown:** sparse Eircode coverage produced uninformative `Unk` groups; fixed by robust address-based fallback extraction.
3. **Affordability coverage mismatch:** income data did not overlap full 2015-2025 range; dashboard plotting was constrained to valid affordability years to avoid misleading lines.
4. **PostgreSQL type constraint:** longer area labels triggered truncation; schema altered to `VARCHAR(120)`.
5. **API schema variability:** dynamic parser logic and fallback filters were required to avoid pipeline breakage.

These fixes improved correctness, resilience, and communication quality.

### I. Technology Choice Justification
#### Python
Python was selected for mature data tooling, rapid iteration, and strong ecosystem support (`pandas`, `numpy`, `requests`, `plotly`, `streamlit`, `sqlalchemy`).

#### MongoDB
Document storage is well-suited for raw API payloads and semi-structured snapshots, enabling schema-flexible ingestion and lineage retention.

#### PostgreSQL
Relational storage is appropriate for structured analytical tables and consistent downstream querying.

#### Streamlit + Plotly
These tools support rapid dashboard development, interactivity, and clear communication to both technical and non-technical stakeholders.

Overall, the stack aligns with LO1-LO4 by balancing development speed, data-model fit, and analytical reproducibility.

## IV. Data Visualization Methodology
The visualization design follows principles of perceptual clarity, task-fit encoding, and narrative progression.

### A. Visual Objectives
The visual layer was designed to answer four questions:

1. How have prices and income changed over time?
2. How has affordability shifted over available overlap years?
3. Which areas are most expensive in a selected year?
4. Are area-level price patterns transient or persistent across years?

### B. Chart-Type Rationale
#### Time-series line charts
Line charts communicate trend continuity and slope differences effectively. They are used for `avg_price_eur` vs `income_eur` and for `affordability_index`.

#### Ranked bar chart
A bar chart is used for top area comparison because rank and magnitude differences are easier to read than in dense scatter alternatives. Transaction count is shown in hover text, preserving readability while retaining context.

#### Area-year heatmap
Heatmaps support matrix-level pattern recognition and quickly reveal persistent high-cost zones versus episodic shifts.

### C. Color and Accessibility Decisions
- Blue was used for neutral trend components.
- Red emphasizes affordability stress.
- Sequential palettes (`Viridis`/`Mako`) encode magnitude gradients in heatmap and comparative views.
- Axis labels and chart titles were written in audience-friendly language to support interpretation during presentation.

### D. Dashboard Composition and Interaction
The dashboard is arranged as a narrative:

1. KPI cards for latest available values,
2. city-level trend chart,
3. affordability trend chart,
4. year slider for area selection,
5. top-area bar chart,
6. area-year heatmap,
7. textual key insights.

This structure supports both executive scanning and exploratory drill-down.

### E. Figure Placement for Report
Include the generated figures in the final IEEE PDF as follows:

![Fig. 1. Dublin price versus income trend (2015-2025).](figures/trend_price_income.png)

**Fig. 1.** Dublin property price and income trend.

![Fig. 2. Affordability index trend for years with valid income overlap.](figures/trend_affordability_index.png)

**Fig. 2.** Affordability index over time.

![Fig. 3. Top Dublin areas by average property price in selected year.](figures/area_comparison_latest_year.png)

**Fig. 3.** Area-level ranking by average price.

![Fig. 4. Area-year heatmap showing persistence of high-price zones.](figures/area_year_heatmap.png)

**Fig. 4.** Area-year heatmap of average prices.

## V. Results and Evaluation
### A. Evidence for Research Question
Processed yearly data shows sustained increase in average property prices across the full period. Income data overlap is available for a shorter subset of years; within this overlap, affordability index values indicate deterioration, meaning housing cost multiples relative to income increased.

Area-level outputs demonstrate persistent heterogeneity. High-price zones remain comparatively high across years, suggesting structural spatial inequality rather than one-off volatility.

### B. Key Quantitative Outcomes
Based on processed outputs and generated insights:

- Dublin average property prices grew substantially across 2015-2025.
- The worst affordability point in available overlap years occurred at the end of the income-covered range.
- Income grew, but at a slower pace than housing prices.
- Area-level variation remained pronounced across the decade.

These outcomes directly support the project hypothesis that affordability pressure increased over time and varied by location.

### C. Interpretation
The findings are consistent with literature indicating that constrained-supply urban markets can exhibit persistent divergence between prices and incomes [3], [4]. Importantly, transaction activity does not necessarily imply improved affordability; market throughput can remain active even when entry barriers for households rise.

For policy interpretation, a city-level average can hide localized stress. Area-level analysis is therefore essential for targeted interventions such as zoning, supply acceleration, infrastructure-linked development, and first-time buyer support aligned to neighborhood conditions.

### D. Evaluation Against Project Objectives
#### Objective 1: Reproducible ETL
Met through modular Python pipeline with deterministic orchestration.

#### Objective 2: Dual-database storage
Met by using MongoDB for raw/semi-structured lineage and PostgreSQL for curated analytical tables.

#### Objective 3: Affordability modeling
Met through year-wise affordability indicators and area-level aggregation.

#### Objective 4: Visual communication
Met through publication-ready figures and an interactive dashboard.

#### Objective 5: Academic reporting
Addressed in this IEEE-structured draft, with references and critical discussion.

### E. Critical Self-Evaluation
Despite robust implementation, several limitations should be acknowledged:

1. Income availability does not fully span all property years, constraining complete-period affordability calculation.
2. Area derivation from address text is practical but still approximate versus official geocoded boundaries.
3. Baseline index does not explicitly adjust for inflation, mortgage rates, or household distributional characteristics.
4. Public API schema drift remains a long-term maintenance risk.

These limitations do not invalidate findings but define the boundary conditions for interpretation.

## VI. Conclusions and Future Work
This project delivered a full analytics pipeline that combines engineering rigor and domain interpretation to evaluate Dublin housing affordability from 2015 to 2025. By integrating heterogeneous public datasets, persisting lineage-aware raw records, producing structured analytical outputs, and presenting interpretable visual results, the system meets both technical and communication goals of the module.

### A. Conclusion in Relation to Research Question
Within available data overlap, the evidence indicates that Dublin housing became less affordable relative to income, and that affordability burden is not geographically uniform. This conclusion is supported by trend divergence and persistent area-level price hierarchy.

### B. Practical Lessons Learned
1. Robust analytics depends as much on schema handling and quality safeguards as on final modeling.
2. Database design must evolve with transformation logic (for example, area label width constraints).
3. Visual clarity requires explicit handling of incomplete coverage to avoid misleading narratives.
4. Reproducibility benefits from storing both raw payloads and processed outputs.

### C. Future Work
The project can be extended in several directions:

1. Build inflation-adjusted and mortgage-aware affordability indicators.
2. Integrate income distribution quantiles for household-segment affordability.
3. Add geospatial joins (small-area boundaries) for policy-grade spatial analysis.
4. Develop forecasting modules with uncertainty intervals (e.g., ARIMA or gradient-boosting approaches).
5. Introduce orchestration, monitoring, and data-quality alerting for scheduled production refreshes.

## Bibliography (IEEE Style)
[1] R. Corrigan, J. McQuinn, and C. O'Toole, "Housing market dynamics in Ireland: supply constraints and demand pressures," *Irish Economic Review*, vol. 50, no. 2, pp. 45-68, 2021.

[2] M. Norris and M. Byrne, "Housing affordability and policy transitions in Ireland," *Housing Studies*, vol. 33, no. 8, pp. 1201-1222, 2018.

[3] OECD, *Brick by Brick: Better Housing Policies*. Paris, France: OECD Publishing, 2022.

[4] E. L. Glaeser and J. Gyourko, "The economic implications of housing supply," *Journal of Economic Perspectives*, vol. 32, no. 1, pp. 3-30, 2018.

[5] Central Statistics Office, "PxStat API datasets and documentation," 2025. [Online]. Available: https://www.cso.ie/en/statistics/

[6] Economic and Social Research Institute, "Housing affordability and distributional pressures in Ireland," Dublin, Ireland, 2023.

[7] Government of Ireland, "Property Price Register," [Online]. Available: https://www.propertypriceregister.ie

[8] S. Few, *Show Me the Numbers: Designing Tables and Graphs to Enlighten*, 2nd ed. Burlingame, CA, USA: Analytics Press, 2012.

[9] C. Ware, *Information Visualization: Perception for Design*, 4th ed. Burlington, MA, USA: Morgan Kaufmann, 2021.
