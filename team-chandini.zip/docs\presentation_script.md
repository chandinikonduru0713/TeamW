# 10-Minute Presentation Plan and Script (Team X)

## Team Details (show on opening video frame)
- Chandini Konduru (25143913)
- Singireddy Sneha (24285854)
- Kapa Adheeshwar Reddy (25122932)

## Slide-by-Slide Structure
1. Title and research question
2. Problem context and motivation
3. Datasets and data complexity
4. Architecture and ETL design
5. MongoDB raw zone implementation
6. PostgreSQL processed zone and schema
7. Trend results (price vs income and affordability)
8. Area comparison and heatmap findings
9. Key insights, implications, and critical evaluation
10. Conclusion, limitations, and future work

## Detailed Script
### Slide 1 - Title and Team (0:00-0:40)
**Presenter: Member 1**  
"Good morning. We are Team X. Our project is Dublin Housing Affordability Analysis for 2015 to 2025. The core question is whether housing has become less affordable relative to income, and whether this pressure varies by area."

### Slide 2 - Problem and Motivation (0:40-1:30)
**Presenter: Member 2**  
"Dublin has experienced sustained housing pressure. Looking only at prices can be misleading, so we evaluate affordability as a relationship between prices and income. This creates a stronger evidence base for policy and planning decisions."

### Slide 3 - Datasets (1:30-2:20)
**Presenter: Member 3**  
"We used official public sources, not Kaggle: Property Price Register CSV, CSO income JSON API, and an optional CSO population JSON API. Each source provides substantial records and satisfies the requirement for mixed structured and semi-structured data."

### Slide 4 - System Architecture (2:20-3:10)
**Presenter: Member 1**  
"The pipeline has five stages: extract, raw storage, transform, processed storage, and visual analytics. Raw data is stored in MongoDB, transformed with Python ETL, and loaded into PostgreSQL for structured analysis and dashboard use."

### Slide 5 - MongoDB Raw Zone Demo (3:10-4:00)
**Presenter: Member 1**  
"We insert original CSV records and full API payloads into MongoDB collections. This preserves lineage and allows us to re-parse if API structures change. We also store parsed API rows as separate raw collections for quality checks."

### Slide 6 - ETL + PostgreSQL (4:00-5:10)
**Presenter: Member 2**  
"During ETL, we clean date and price fields, filter Dublin and years 2015 to 2025, handle missing values, and aggregate yearly metrics. We merge with income to compute the affordability index, then load processed tables into PostgreSQL for queryable outputs."

### Slide 7 - Time Trend Results (5:10-6:25)
**Presenter: Member 3**  
"This chart compares average property price and income. Prices rise faster in most years. The affordability index trend confirms worsening pressure, meaning households need more annual income multiples to purchase average properties."

### Slide 8 - Spatial Results (6:25-7:35)
**Presenter: Member 2**  
"Area-level comparisons show strong geographic variation. High-price areas are persistently expensive across years in the heatmap, indicating structural, not random, spatial inequality."

### Slide 9 - Insights and Critical Evaluation (7:35-8:50)
**Presenter: Member 3**  
"Three key findings: first, persistent growth-rate divergence between price and income; second, affordability stress intensifies in later years; third, area inequality remains stable. Limitations include coarse area proxy and aggregate income representation."

### Slide 10 - Conclusion and Future Work (8:50-10:00)
**Presenter: Member 1**  
"We conclude that Dublin housing became less affordable relative to income over 2015 to 2025. Next steps include inflation-adjusted affordability, mortgage-cost integration, and predictive modelling. Thank you."

## Team Member Allocation
- **Member 1 (Lead: Data Collection + MongoDB):** Slides 1, 4, 5, 10
- **Member 2 (Lead: ETL + Processing):** Slides 2, 6, 8
- **Member 3 (Lead: Analysis + Visualization):** Slides 3, 7, 9

## Cross-Stage Participation Statement
Each member contributed to all methodology stages (dataset selection, ETL validation, results interpretation, report edits, and presentation rehearsal), with differentiated primary ownership for accountability.
