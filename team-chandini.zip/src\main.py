import logging
import os
from datetime import datetime
from pathlib import Path

from dotenv import load_dotenv
from sqlalchemy.exc import SQLAlchemyError

from extract import (
    fetch_cso_json_safe,
    insert_population_raw_to_mongo,
    insert_raw_to_mongo,
    load_property_prices,
    parse_cso_dataset,
    save_local_raw,
)
from load import create_postgres_tables, load_to_postgres
from transform import (
    aggregate_affordability,
    clean_income_data,
    clean_population_data,
    clean_property_data,
    generate_key_insights,
    save_processed_outputs,
)


logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")


def run_pipeline() -> None:
    load_dotenv()

    base_dir = Path(__file__).resolve().parents[1]
    raw_dir = base_dir / "data" / "raw"
    processed_dir = base_dir / "data" / "processed"

    property_csv = Path(os.getenv("PROPERTY_CSV_PATH", str(raw_dir / "property_prices.csv")))
    cso_income_api = os.getenv(
        "CSO_INCOME_API_URL",
        "https://ws.cso.ie/public/api.restful/PxStat.Data.Cube_API.ReadDataset/SIA14/JSON-stat/2.0/en",
    )
    cso_population_api = os.getenv(
        "CSO_POPULATION_API_URL",
        "https://ws.cso.ie/public/api.restful/PxStat.Data.Cube_API.ReadDataset/F1015/JSON-stat/2.0/en",
    )
    mongo_uri = os.getenv("MONGO_URI", "mongodb://localhost:27017")
    mongo_db = os.getenv("MONGO_DB", "dublin_housing_project")
    pg_uri = os.getenv("POSTGRES_URI", "postgresql+psycopg2://postgres:postgres@localhost:5432/dublin_housing")
    start_year = int(os.getenv("ANALYSIS_START_YEAR", "2015"))
    end_year = int(os.getenv("ANALYSIS_END_YEAR", "2025"))

    # Extract
    property_df = load_property_prices(property_csv)
    income_payload = fetch_cso_json_safe(cso_income_api)
    income_raw_df = parse_cso_dataset(income_payload)
    population_payload = fetch_cso_json_safe(cso_population_api)
    population_raw_df = parse_cso_dataset(population_payload)

    # Raw storage
    insert_raw_to_mongo(mongo_uri, mongo_db, property_df, income_payload, income_raw_df)
    insert_population_raw_to_mongo(mongo_uri, mongo_db, population_payload, population_raw_df)
    save_local_raw(property_df, income_payload, raw_dir, population_payload=population_payload)

    # Transform
    property_clean = clean_property_data(property_df, start_year=start_year, end_year=end_year)
    income_clean = clean_income_data(income_raw_df, start_year=start_year, end_year=end_year)
    population_clean = clean_population_data(population_raw_df, start_year=start_year, end_year=end_year)
    yearly_df, area_df = aggregate_affordability(property_clean, income_clean, population_clean)
    insights_df = generate_key_insights(yearly_df)
    save_processed_outputs(yearly_df, area_df, processed_dir)
    insights_path = processed_dir / "key_insights.csv"
    try:
        insights_df.to_csv(insights_path, index=False)
    except PermissionError:
        fallback = processed_dir / f"key_insights_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        insights_df.to_csv(fallback, index=False)
        logging.warning("key_insights.csv is locked. Wrote fallback: %s", fallback.name)

    # Load structured
    try:
        create_postgres_tables(pg_uri)
        load_to_postgres(pg_uri, yearly_df, area_df, insights_df)
    except SQLAlchemyError as exc:
        logging.warning("PostgreSQL load skipped due to connection error: %s", exc)

    logging.info("ETL pipeline completed successfully")


if __name__ == "__main__":
    run_pipeline()
