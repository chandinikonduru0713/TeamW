# Final Submission Checklist (NCI Analytics Programming & Data Visualisation)

## 1) Report Package
- [ ] Convert `docs/ieee_report_draft.md` into IEEE formatted PDF.
- [x] Add full team names and student numbers on title page.
- [ ] Ensure in-text citations and bibliography follow IEEE style.
- [ ] Save as `TeamX.pdf`.

## 2) Code Artefact Package
- [ ] Ensure `.env` is not included in zip (keep `.env.example` only).
- [ ] Confirm raw + processed pipeline runs locally (`run_all.ps1`).
- [ ] Confirm dashboard starts (`streamlit run dashboard/app.py`).
- [ ] Create zip archive with `package_submission.ps1`.
- [ ] Rename as `TeamX.zip` if needed.

## 3) Presentation Package
- [ ] Use `docs/presentation_script.md` as speaking guide.
- [x] Include team names + student numbers at start of video script.
- [ ] Keep final video <= 10 minutes.
- [ ] Save as `TeamX.mp4`.

## 4) Individual Work Breakdown
- [ ] Export each file in `docs/work_breakdown/` to separate PDF.
- [x] Replace placeholder student numbers.
- [ ] Name files as each student number, e.g. `x12345678.pdf`.

## 5) Quality Checks Before Upload
- [ ] Datasets are non-Kaggle and source URLs documented.
- [ ] At least one semi-structured JSON/API dataset is used.
- [ ] Raw data is stored in MongoDB and processed output in PostgreSQL.
- [ ] Visual findings include at least three strong insights.
- [ ] All required files uploaded to correct Moodle links before deadline.
