import logging

import pandas as pd
from sqlalchemy import create_engine, text


logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")


def get_engine(pg_uri: str):
    return create_engine(pg_uri)


def create_postgres_tables(pg_uri: str) -> None:
    engine = get_engine(pg_uri)
    ddl = """
    CREATE TABLE IF NOT EXISTS dublin_affordability_yearly (
        year INTEGER PRIMARY KEY,
        avg_price_eur DOUBLE PRECISION,
        median_price_eur DOUBLE PRECISION,
        sales_count INTEGER,
        income_eur DOUBLE PRECISION,
        population DOUBLE PRECISION,
        affordability_index DOUBLE PRECISION,
        price_growth_pct DOUBLE PRECISION,
        income_growth_pct DOUBLE PRECISION,
        affordability_delta_pct DOUBLE PRECISION,
        price_per_1000_residents DOUBLE PRECISION
    );

    CREATE TABLE IF NOT EXISTS dublin_affordability_area (
        year INTEGER,
        area VARCHAR(120),
        avg_price_eur DOUBLE PRECISION,
        transaction_count INTEGER
    );

    CREATE TABLE IF NOT EXISTS project_insights (
        insight TEXT,
        value TEXT
    );

    ALTER TABLE dublin_affordability_area
    ALTER COLUMN area TYPE VARCHAR(120);
    """
    with engine.begin() as conn:
        conn.execute(text(ddl))
    logging.info("Ensured PostgreSQL tables exist")


def load_to_postgres(pg_uri: str, yearly_df: pd.DataFrame, area_df: pd.DataFrame, insights_df: pd.DataFrame) -> None:
    engine = get_engine(pg_uri)
    with engine.begin() as conn:
        conn.execute(text("TRUNCATE TABLE dublin_affordability_area;"))
        conn.execute(text("TRUNCATE TABLE project_insights;"))
        # yearly table has PK year, so clear then append for deterministic pipeline
        conn.execute(text("DELETE FROM dublin_affordability_yearly;"))

    yearly_df.to_sql("dublin_affordability_yearly", con=engine, if_exists="append", index=False)
    area_df.to_sql("dublin_affordability_area", con=engine, if_exists="append", index=False)
    insights_df.to_sql("project_insights", con=engine, if_exists="append", index=False)
    logging.info("Loaded processed data into PostgreSQL")
