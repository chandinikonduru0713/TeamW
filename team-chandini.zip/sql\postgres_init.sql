CREATE DATABASE dublin_housing;

\c dublin_housing;

CREATE TABLE IF NOT EXISTS dublin_affordability_yearly (
    year INTEGER PRIMARY KEY,
    avg_price_eur DOUBLE PRECISION,
    median_price_eur DOUBLE PRECISION,
    sales_count INTEGER,
    income_eur DOUBLE PRECISION,
    population DOUBLE PRECISION,
    affordability_index DOUBLE PRECISION,
    price_growth_pct DOUBLE PRECISION,
    income_growth_pct DOUBLE PRECISION,
    affordability_delta_pct DOUBLE PRECISION,
    price_per_1000_residents DOUBLE PRECISION
);

CREATE TABLE IF NOT EXISTS dublin_affordability_area (
    year INTEGER,
    area VARCHAR(20),
    avg_price_eur DOUBLE PRECISION,
    transaction_count INTEGER
);

CREATE TABLE IF NOT EXISTS project_insights (
    insight TEXT,
    value TEXT
);
