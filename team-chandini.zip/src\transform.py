import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Tuple

import numpy as np
import pandas as pd


logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")


def _extract_area_label(address: object, eircode: object) -> str:
    """Build a stable area label using eircode first, then address text."""
    eircode_text = "" if pd.isna(eircode) else str(eircode).strip().upper()
    if eircode_text:
        eir_prefix = re.sub(r"[^A-Z0-9]", "", eircode_text)[:3]
        if eir_prefix:
            return eir_prefix

    address_text = "" if pd.isna(address) else str(address).strip()
    if not address_text:
        return "Unknown"

    # Prefer Dublin postal district where present (e.g., "DUBLIN 7").
    district_match = re.search(r"\bDUBLIN\s*(\d{1,2})\b", address_text, flags=re.IGNORECASE)
    if district_match:
        return f"Dublin {int(district_match.group(1))}"

    # Otherwise use the most specific non-empty address segment from the end.
    parts = [p.strip() for p in address_text.split(",") if p and p.strip()]
    ignored = {"DUBLIN", "CO DUBLIN", "COUNTY DUBLIN", "IRELAND"}
    for part in reversed(parts):
        compact = re.sub(r"[.\s]+", " ", part).strip().upper()
        if compact in ignored or compact.startswith("DUBLIN "):
            continue
        if compact:
            return part.title()

    return "Unknown"


def clean_property_data(df: pd.DataFrame, start_year: int = 2015, end_year: int = 2025) -> pd.DataFrame:
    """Standardize property register and keep Dublin transactions."""
    renamed = df.rename(
        columns={
            "Date of Sale (dd/mm/yyyy)": "sale_date",
            "Address": "address",
            "Postal Code": "eircode",
            "County": "county",
            "Price ()": "price_eur",
            "Price (€)": "price_eur",
            "Description of Property": "property_desc",
            "Property Size Description": "size_desc",
        }
    ).copy()

    required_cols = {"sale_date", "county", "price_eur"}
    missing = required_cols - set(renamed.columns)
    if missing:
        sample_cols = ", ".join(list(renamed.columns[:12]))
        raise ValueError(
            "Invalid property dataset schema. "
            f"Missing required columns: {missing}. "
            f"Detected columns include: {sample_cols}. "
            "Please replace data/raw/property_prices.csv with the official "
            "Property Price Register CSV export."
        )

    renamed["county"] = renamed["county"].astype(str).str.strip().str.lower()
    dublin_df = renamed[renamed["county"].str.contains("dublin", na=False)].copy()

    dublin_df["sale_date"] = pd.to_datetime(dublin_df["sale_date"], errors="coerce", dayfirst=True)
    dublin_df["year"] = dublin_df["sale_date"].dt.year

    dublin_df["price_eur"] = (
        dublin_df["price_eur"]
        .astype(str)
        .str.replace(",", "", regex=False)
        .str.replace("€", "", regex=False)
        .str.strip()
    )
    dublin_df["price_eur"] = pd.to_numeric(dublin_df["price_eur"], errors="coerce")

    dublin_df = dublin_df.dropna(subset=["price_eur", "year"])
    dublin_df = dublin_df[(dublin_df["year"] >= start_year) & (dublin_df["year"] <= end_year)]
    dublin_df = dublin_df[dublin_df["price_eur"] > 10000]

    logging.info("Cleaned property dataset rows: %s", len(dublin_df))
    return dublin_df


def clean_income_data(df: pd.DataFrame, start_year: int = 2015, end_year: int = 2025) -> pd.DataFrame:
    """Filter and standardize income indicators for Dublin and Ireland."""
    working = df.copy()

    # Normalize common CSO aliases first.
    working = working.rename(columns={"STATISTIC": "statistic", "TLIST(A1)": "time", "C02199V02655": "region"})

    if "value" not in set(working.columns):
        raise ValueError("Income dataset must contain a 'value' column.")

    if "time" not in set(working.columns):
        possible_time = [c for c in working.columns if "TIME" in c.upper() or "TLIST" in c.upper()]
        if possible_time:
            working = working.rename(columns={possible_time[0]: "time"})
        else:
            raise ValueError(
                f"Income dataset missing time column. Columns available: {list(working.columns)}"
            )

    # Try explicit region labels; if unavailable, choose the first non-time/non-value/non-stat dimension.
    if "region" not in set(working.columns):
        possible_region = [c for c in working.columns if "REGION" in c.upper() or "COUNTY" in c.upper()]
        if possible_region:
            working = working.rename(columns={possible_region[0]: "region"})
        else:
            excluded = {"value", "time", "statistic"}
            fallback_dims = [c for c in working.columns if c.lower() not in excluded]
            if fallback_dims:
                working = working.rename(columns={fallback_dims[0]: "region"})
            else:
                # If no dimension remains, default to State-level aggregation only.
                working["region"] = "State"

    working["year"] = pd.to_numeric(working["time"], errors="coerce")
    working["income_eur"] = pd.to_numeric(working["value"], errors="coerce")
    working["region"] = working["region"].astype(str)

    # CSO API labels vary a lot. First try location labels, then fallback to all rows.
    filtered = working[
        working["region"].str.contains("Dublin|State|Ireland", case=False, na=False)
    ].copy()
    if filtered.empty:
        logging.warning(
            "Income region labels did not match Dublin/State/Ireland. Falling back to all region rows."
        )
        filtered = working.copy()

    filtered = filtered.dropna(subset=["year", "income_eur"])
    filtered = filtered[(filtered["year"] >= start_year) & (filtered["year"] <= end_year)]

    # Keep one value per year by averaging available records.
    grouped = filtered.groupby("year", as_index=False)["income_eur"].mean()
    logging.info("Cleaned income dataset rows: %s", len(grouped))
    return grouped


def clean_population_data(df: pd.DataFrame, start_year: int = 2015, end_year: int = 2025) -> pd.DataFrame:
    """Extract a Dublin population yearly series from a CSO parsed frame."""
    if df.empty:
        return pd.DataFrame(columns=["year", "population"])

    working = df.copy()
    if "value" not in working.columns:
        return pd.DataFrame(columns=["year", "population"])

    time_col = next((c for c in working.columns if "TLIST" in c.upper() or "TIME" in c.upper()), None)
    region_col = next((c for c in working.columns if "COUNTY" in c.upper() or "REGION" in c.upper()), None)
    if time_col is None:
        return pd.DataFrame(columns=["year", "population"])

    working["year"] = pd.to_numeric(working[time_col], errors="coerce")
    working["population"] = pd.to_numeric(working["value"], errors="coerce")

    if region_col:
        working = working[working[region_col].astype(str).str.contains("Dublin", case=False, na=False)]

    out = (
        working.dropna(subset=["year", "population"])
        .query("@start_year <= year <= @end_year")
        .groupby("year", as_index=False)["population"]
        .mean()
    )
    return out


def aggregate_affordability(
    property_df: pd.DataFrame, income_df: pd.DataFrame, population_df: pd.DataFrame | None = None
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Compute yearly affordability and Dublin area-level comparison."""
    yearly_prices = (
        property_df.groupby("year", as_index=False)
        .agg(
            avg_price_eur=("price_eur", "mean"),
            median_price_eur=("price_eur", "median"),
            sales_count=("price_eur", "size"),
        )
        .sort_values("year")
    )

    merged = yearly_prices.merge(income_df, how="left", on="year")
    if population_df is not None and not population_df.empty:
        merged = merged.merge(population_df, how="left", on="year")
    merged["affordability_index"] = merged["avg_price_eur"] / merged["income_eur"]
    merged["price_growth_pct"] = merged["avg_price_eur"].pct_change() * 100
    merged["income_growth_pct"] = merged["income_eur"].pct_change() * 100
    merged["affordability_delta_pct"] = merged["affordability_index"].pct_change() * 100
    if "population" in merged.columns:
        merged["price_per_1000_residents"] = (merged["avg_price_eur"] / merged["population"]) * 1000

    # Area label from eircode when present, otherwise derive from address.
    area_df = property_df.copy()
    area_df["area"] = area_df.apply(
        lambda row: _extract_area_label(row.get("address"), row.get("eircode")), axis=1
    )
    area_summary = (
        area_df.groupby(["year", "area"], as_index=False)
        .agg(avg_price_eur=("price_eur", "mean"), transaction_count=("price_eur", "size"))
    )
    area_summary = area_summary[area_summary["transaction_count"] >= 10]

    return merged, area_summary


def save_processed_outputs(yearly_df: pd.DataFrame, area_df: pd.DataFrame, output_dir: Path) -> None:
    """Save transformed datasets to processed folder."""
    output_dir.mkdir(parents=True, exist_ok=True)
    yearly_path = output_dir / "dublin_affordability_yearly.csv"
    area_path = output_dir / "dublin_affordability_by_area.csv"

    try:
        yearly_df.to_csv(yearly_path, index=False)
    except PermissionError:
        fallback = output_dir / f"dublin_affordability_yearly_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        yearly_df.to_csv(fallback, index=False)
        logging.warning("Yearly output file is locked. Wrote fallback: %s", fallback.name)

    try:
        area_df.to_csv(area_path, index=False)
    except PermissionError:
        fallback = output_dir / f"dublin_affordability_by_area_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        area_df.to_csv(fallback, index=False)
        logging.warning("Area output file is locked. Wrote fallback: %s", fallback.name)

    logging.info("Saved processed outputs to %s", output_dir)


def generate_key_insights(yearly_df: pd.DataFrame) -> pd.DataFrame:
    """Create a compact insights table for report/dashboard usage."""
    df = yearly_df.copy().sort_values("year")
    if df.empty:
        return pd.DataFrame(columns=["insight", "value"])

    first = df.iloc[0]
    last = df.iloc[-1]
    if "affordability_index" not in df.columns or df["affordability_index"].dropna().empty:
        return pd.DataFrame(
            [
                {"insight": "Insufficient income overlap for affordability index", "value": "Check income dataset coverage"},
                {
                    "insight": "Average Dublin property price growth (2015-2025)",
                    "value": f"{((last['avg_price_eur'] / first['avg_price_eur']) - 1) * 100:.2f}%",
                },
            ]
        )

    max_aff = df.loc[df["affordability_index"].idxmax()]

    price_growth = ((last["avg_price_eur"] / first["avg_price_eur"]) - 1) * 100

    insights = [
        {
            "insight": "Average Dublin property price growth (2015-2025)",
            "value": f"{price_growth:.2f}%",
        },
        {
            "insight": "Worst affordability year",
            "value": f"{int(max_aff['year'])} (index={max_aff['affordability_index']:.2f})",
        },
    ]
    if "income_eur" in df.columns:
        income_valid = df.dropna(subset=["income_eur"]).sort_values("year")
        if len(income_valid) >= 2:
            inc_first = income_valid.iloc[0]
            inc_last = income_valid.iloc[-1]
            income_growth = ((inc_last["income_eur"] / inc_first["income_eur"]) - 1) * 100
            insights.append(
                {
                    "insight": "Income growth over available income years",
                    "value": f"{income_growth:.2f}% ({int(inc_first['year'])}-{int(inc_last['year'])})",
                }
            )
        else:
            insights.append(
                {
                    "insight": "Income growth over available income years",
                    "value": "Not enough income points available from API",
                }
            )

    if "population" in df.columns and df["population"].notna().any():
        pop_valid = df.dropna(subset=["population"]).sort_values("year")
        if not pop_valid.empty:
            latest_pop = pop_valid.iloc[-1]
            insights.append(
                {
                    "insight": "Average price per 1,000 Dublin residents (latest available year)",
                    "value": f"{(latest_pop['avg_price_eur'] / latest_pop['population']) * 1000:.2f} ({int(latest_pop['year'])})",
                }
            )
    return pd.DataFrame(insights)
