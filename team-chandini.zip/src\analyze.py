import logging
from datetime import datetime
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns


logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")


def run_analysis() -> None:
    base_dir = Path(__file__).resolve().parents[1]
    processed_dir = base_dir / "data" / "processed"
    figures_dir = base_dir / "docs" / "figures"
    figures_dir.mkdir(parents=True, exist_ok=True)

    yearly_path = processed_dir / "dublin_affordability_yearly.csv"
    area_path = processed_dir / "dublin_affordability_by_area.csv"
    if not yearly_path.exists():
        raise FileNotFoundError("Run ETL first: python src/main.py")

    yearly_df = pd.read_csv(yearly_path).sort_values("year")
    area_df = pd.read_csv(area_path) if area_path.exists() else pd.DataFrame()

    sns.set_theme(style="whitegrid")

    plt.figure(figsize=(10, 5))
    plt.plot(yearly_df["year"], yearly_df["avg_price_eur"], marker="o", label="Average Price")
    plt.plot(yearly_df["year"], yearly_df["income_eur"], marker="o", label="Income")
    plt.title("Dublin Price vs Income Trend")
    plt.xlabel("Year")
    plt.ylabel("EUR")
    plt.legend()
    plt.tight_layout()
    plt.savefig(figures_dir / "trend_price_income.png", dpi=180)
    plt.close()

    plt.figure(figsize=(10, 5))
    plt.plot(yearly_df["year"], yearly_df["affordability_index"], marker="o", color="#b22222")
    plt.title("Affordability Index (Price / Income)")
    plt.xlabel("Year")
    plt.ylabel("Index")
    plt.tight_layout()
    plt.savefig(figures_dir / "trend_affordability_index.png", dpi=180)
    plt.close()

    if not area_df.empty:
        latest_year = int(area_df["year"].max())
        top_area = area_df[area_df["year"] == latest_year].sort_values("avg_price_eur", ascending=False).head(15)
        plt.figure(figsize=(12, 6))
        sns.barplot(data=top_area, x="area", y="avg_price_eur", palette="viridis")
        plt.title(f"Top Dublin Areas by Average Price ({latest_year})")
        plt.xlabel("Area")
        plt.ylabel("Average Price (EUR)")
        plt.xticks(rotation=45, ha="right")
        plt.tight_layout()
        plt.savefig(figures_dir / "area_comparison_latest_year.png", dpi=180)
        plt.close()

        heatmap_data = area_df.pivot_table(index="area", columns="year", values="avg_price_eur", aggfunc="mean")
        if len(heatmap_data.index) > 40:
            heatmap_data = heatmap_data.nlargest(40, columns=latest_year)
        plt.figure(figsize=(12, 10))
        sns.heatmap(heatmap_data, cmap="mako", linewidths=0.1)
        plt.title("Dublin Area-Year Price Heatmap")
        plt.xlabel("Year")
        plt.ylabel("Area")
        plt.tight_layout()
        plt.savefig(figures_dir / "area_year_heatmap.png", dpi=180)
        plt.close()

    insights = []
    if len(yearly_df) >= 2:
        first = yearly_df.iloc[0]
        last = yearly_df.iloc[-1]
        insights.append(
            {
                "insight": "Price growth exceeded income growth",
                "detail": (
                    f"Prices increased by {((last['avg_price_eur'] / first['avg_price_eur']) - 1) * 100:.2f}% "
                    f"while income increased by {((last['income_eur'] / first['income_eur']) - 1) * 100:.2f}%."
                ),
            }
        )
        worst = yearly_df.loc[yearly_df["affordability_index"].idxmax()]
        insights.append(
            {
                "insight": "Worst affordability year",
                "detail": f"Year {int(worst['year'])} had the highest index value ({worst['affordability_index']:.2f}).",
            }
        )
        if "sales_count" in yearly_df.columns:
            least_liquid = yearly_df.loc[yearly_df["sales_count"].idxmin()]
            insights.append(
                {
                    "insight": "Lowest transaction liquidity",
                    "detail": f"Year {int(least_liquid['year'])} had the lowest sales count ({int(least_liquid['sales_count'])}).",
                }
            )
    insights_path = processed_dir / "analysis_insights.csv"
    try:
        pd.DataFrame(insights).to_csv(insights_path, index=False)
    except PermissionError:
        fallback = processed_dir / f"analysis_insights_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        pd.DataFrame(insights).to_csv(fallback, index=False)
        logging.warning("analysis_insights.csv is locked. Wrote fallback: %s", fallback.name)
    logging.info("Saved analysis figures to %s", figures_dir)


if __name__ == "__main__":
    run_analysis()
