import itertools
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Sequence

import pandas as pd
import requests
from pymongo import MongoClient
from pymongo.errors import PyMongoError


logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")


def load_property_prices(csv_path: Path) -> pd.DataFrame:
    """Load Property Price Register CSV."""
    if not csv_path.exists():
        raise FileNotFoundError(f"Property CSV not found: {csv_path}")
    df = pd.read_csv(csv_path, low_memory=False)
    logging.info("Loaded property price records: %s", len(df))
    return df


def fetch_cso_json(api_url: str, timeout: int = 60) -> Dict[str, Any]:
    """Fetch data from CSO JSON API endpoint."""
    response = requests.get(api_url, timeout=timeout)
    response.raise_for_status()
    data = response.json()
    logging.info("Fetched CSO payload from API")
    return data


def fetch_cso_json_safe(api_url: str, timeout: int = 60) -> Dict[str, Any]:
    """Fetch a CSO payload and return an empty schema on API failure."""
    try:
        return fetch_cso_json(api_url, timeout=timeout)
    except requests.RequestException as exc:
        logging.warning("CSO fetch failed for %s with error: %s", api_url, exc)
        return {"dataset": {"id": [], "dimension": {}, "value": []}}


def _ordered_labels(cat: Dict[str, Any]) -> Sequence[str]:
    idx_map = cat.get("index", {})
    if isinstance(idx_map, dict):
        idx_to_label = {int(v): k for k, v in idx_map.items()}
        return [idx_to_label[i] for i in sorted(idx_to_label.keys())]
    if isinstance(idx_map, list):
        return list(idx_map)
    return []


def parse_cso_dataset(payload: Dict[str, Any]) -> pd.DataFrame:
    """
    Parse a generic CSO PxStat JSON-stat style response into a tabular DataFrame.
    """
    # CSO can return either {"dataset": {...}} or the dataset object directly.
    if "dataset" in payload and isinstance(payload["dataset"], dict):
        dataset = payload["dataset"]
    elif payload.get("class") == "dataset":
        dataset = payload
    else:
        logging.warning("Unexpected CSO payload shape. Returning empty parsed DataFrame.")
        return pd.DataFrame(columns=["value"])

    dimensions = dataset.get("dimension", {})
    values = dataset.get("value", [])
    dim_ids = dataset.get("id", [])
    if not dim_ids:
        return pd.DataFrame(columns=["value"])

    labels: List[Sequence[str]] = []
    for dim_id in dim_ids:
        cat = dimensions[dim_id]["category"]
        ordered_labels = _ordered_labels(cat)
        labels.append(ordered_labels)

    rows: List[Dict[str, Any]] = []
    for value_index, combo in enumerate(itertools.product(*labels)):
        if value_index >= len(values):
            break
        row = {dim_name: dim_value for dim_name, dim_value in zip(dim_ids, combo)}
        row["value"] = values[value_index]
        rows.append(row)
    df = pd.DataFrame(rows)
    logging.info("Parsed CSO rows: %s", len(df))
    return df


def insert_raw_to_mongo(
    mongo_uri: str,
    db_name: str,
    property_df: pd.DataFrame,
    income_payload: Dict[str, Any],
    income_df: pd.DataFrame,
) -> None:
    """Insert raw extracted data into MongoDB collections."""
    try:
        client = MongoClient(mongo_uri, serverSelectionTimeoutMS=12000)
        db = client[db_name]
        db.command("ping")

        db.property_prices_raw.delete_many({})
        db.cso_income_raw.delete_many({})
        db.cso_income_parsed_raw.delete_many({})

        if not property_df.empty:
            db.property_prices_raw.insert_many(property_df.to_dict(orient="records"))

        db.cso_income_raw.insert_one({"payload": income_payload})

        if not income_df.empty:
            db.cso_income_parsed_raw.insert_many(income_df.to_dict(orient="records"))

        client.close()
        logging.info("Inserted raw data into MongoDB database '%s'", db_name)
    except PyMongoError as exc:
        logging.warning("MongoDB raw insert skipped due to connection error: %s", exc)


def insert_population_raw_to_mongo(
    mongo_uri: str,
    db_name: str,
    population_payload: Dict[str, Any],
    population_df: pd.DataFrame,
) -> None:
    """Insert optional raw population dataset into MongoDB."""
    try:
        client = MongoClient(mongo_uri, serverSelectionTimeoutMS=12000)
        db = client[db_name]
        db.command("ping")
        db.cso_population_raw.delete_many({})
        db.cso_population_parsed_raw.delete_many({})
        db.cso_population_raw.insert_one({"payload": population_payload})
        if not population_df.empty:
            db.cso_population_parsed_raw.insert_many(population_df.to_dict(orient="records"))
        client.close()
        logging.info("Inserted population raw data into MongoDB database '%s'", db_name)
    except PyMongoError as exc:
        logging.warning("MongoDB population insert skipped due to connection error: %s", exc)


def save_local_raw(
    property_df: pd.DataFrame,
    income_payload: Dict[str, Any],
    raw_dir: Path,
    population_payload: Dict[str, Any] | None = None,
) -> None:
    """Optional local persistence for traceability and reproducibility."""
    raw_dir.mkdir(parents=True, exist_ok=True)
    raw_path = raw_dir / "property_prices_raw.csv"
    try:
        property_df.to_csv(raw_path, index=False)
    except PermissionError:
        fallback = raw_dir / f"property_prices_raw_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        property_df.to_csv(fallback, index=False)
        logging.warning("property_prices_raw.csv is locked. Wrote fallback snapshot: %s", fallback.name)
    with open(raw_dir / "cso_income_raw.json", "w", encoding="utf-8") as file:
        json.dump(income_payload, file, indent=2)
    if population_payload:
        with open(raw_dir / "cso_population_raw.json", "w", encoding="utf-8") as file:
            json.dump(population_payload, file, indent=2)
    logging.info("Saved raw local snapshots to %s", raw_dir)
